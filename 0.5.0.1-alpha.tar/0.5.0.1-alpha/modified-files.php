<?php
return [
	"galastri/VERSION",
	"updater",
];
