<?php
return [
	'galastri/VERSION',
	'galastri/extensions/output/File.php',
];
