<?php
return [
	"galastri/VERSION",
];
